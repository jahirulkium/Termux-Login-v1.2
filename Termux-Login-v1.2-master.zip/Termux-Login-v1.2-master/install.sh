apt install figlet  
apt install ruby 
gem install lolcat
apt install python
apt install python2 
pip install requests
pip2 install requests
